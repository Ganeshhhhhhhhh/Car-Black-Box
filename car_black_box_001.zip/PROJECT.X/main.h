/* 
 * File:   main.h
 * Author: Sai ganesh
 *
 * Created on 25 September, 2023, 5:18 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "mkp.h"
#include "eeprom.h"
#include "clcd.h"
#include "adc.h"
#include "uart.h"
#include "i2c.h"
#include "ds1307.h"

void save_event(char event[]);
void menu();
void read_menu();
void clearlog();
void downloadlog(void);
void printlog(unsigned char i,unsigned char sno);
void viewlog();
void changepassword(void);
void read_password();
void settime();
void savetime(char hour, char min, char sec);

#endif	/* MAIN_H */

