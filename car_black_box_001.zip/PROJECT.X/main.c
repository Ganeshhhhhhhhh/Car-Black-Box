/*
 * File:   main.c
 * Author: Sai ganesh
 *
 * Created on 25 September, 2023, 5:16 PM
 */

/*to include header files*/
#include <xc.h>
#include "main.h"
#include <string.h>

static void init_config(void) {
    init_uart();
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_i2c();
    init_ds1307();    
    read_password();   
}
/*Global variables for car black box*/
unsigned char time[9] = "00:00:00";
char dashboard[17] = "Time     EV   SP";
unsigned short speedval = 0;
char speed[3] = {};
char pass[5] = "0101";
unsigned char event[8][3] = {"ON", "GR", "GN", "G1", "G2", "G3", "G4", "C "};
unsigned char index = 0;
unsigned char eventflag = 1;
unsigned char lap, lapflag;
unsigned char overflowflag, dflag, ch, menuflag, log_flag, kflag = 0;

/*main function to get speed and change the gears and display them in dashboard */
void main(void) {
    init_config();
    unsigned char key = ALL_RELEASED;
    while (1) {
        gettime();
        clcd_print(dashboard, LINE1(0));
        clcd_print(time, LINE2(0));
        speedval = read_adc(CHANNEL4);
        speed[2] = '\0';

        speedval = speedval / 10.33;
        speed[0] = (speedval / 10) + 48;
        speed[1] = (speedval % 10) + 48;

        clcd_print(speed, LINE2(14));
        key = read_switches(STATE_CHANGE);

        if (key == MK_SW1) {
            eventflag = 1;
            index = 7;
        } else if (key == MK_SW2 && key == MK_SW3 && index == 7) {
            index = 2;
            eventflag = 1;
        } else if (key == MK_SW2) {
            if (index < 6) {
                index++;
                eventflag = 1;
            }
        } else if (key == MK_SW3) {
            if (index > 1) {
                index--;
                eventflag = 1;
            }
        } else if (key == MK_SW11) {
            dflag = 1;
            read_menu();
        }
        clcd_print(event[index], LINE2(9));
        if (eventflag == 1) {
            eventflag = 0;
            save_event(event[index]);
            lap++;
            if (lap == 10) {
                overflowflag = 1;
                lap = 0;
            }
        }
    }
}
/*to save each and every events and save them in external eeprom*/
void save_event(char event[]) {
    char log[] = {time[0], time[1], time[3], time[4], time[6], time[7], event[0], event[1], speed[0], speed[1]};
    for (unsigned int i = 0; i < 10; i++) {
        write_ext_eeprom(lap * 10 + i, log[i]);
    }
}

/*function to read password from the external eeprom and save them in the external eeprom*/
void read_password() {
    unsigned char ch = read_ext_eeprom(124);

    if (ch == '*') {
        pass[0] = read_ext_eeprom(120);
        pass[1] = read_ext_eeprom(121);
        pass[2] = read_ext_eeprom(122);
        pass[3] = read_ext_eeprom(123);
    } else {
        write_ext_eeprom(120, pass[0]);
        write_ext_eeprom(121, pass[1]);
        write_ext_eeprom(122, pass[2]);
        write_ext_eeprom(123, pass[3]);
        write_ext_eeprom(124, '*');
    }
}

/*once the user enters the correct password, they will be having 3 attempts,
 if the user exceeds more than 3 wrong attempts, they will be blocked for 
 120 seconds*/
void read_menu() {
    unsigned char count = 0;
    unsigned int wait = 0;
    unsigned char attempt = 3;
    char i = 0;
    unsigned char key = ALL_RELEASED;
    char arr[4];
    arr[4] = '\0';

    CLEAR_DISP_SCREEN;
    clcd_print("ENTER PASSWORD", LINE1(0));

    while (dflag) {
        key = read_switches(STATE_CHANGE);
        if (wait++ < 12000) {
            clcd_putch('_', LINE2(i));
        } else if (wait++ < 24000) {
            clcd_putch(' ', LINE2(i));
        } else {
            wait = 0;
            count++;
        }
        if (count == 5) {
            dflag = 0;
            continue;
        }
        if (key == MK_SW11) {
            arr[i] = '0';
            clcd_putch('*', LINE2(i));
            i++;
        }
        if (key == MK_SW12) {
            arr[i] = '1';
            clcd_putch('*', LINE2(i));
            i++;
        }
        if (i == 4) {
            if (strcmp(pass, arr) == 0) {
                menuflag = 1;
                menu();
                break;
            } else {
                if (attempt) {
                    i = 0;
                    ch = attempt + 48;
                    CLEAR_DISP_SCREEN;
                    clcd_print("TRY AGAIN", LINE1(0));
                    clcd_putch(ch, LINE2(0));
                    clcd_print("ATTEMPTS LEFT", LINE2(2));
                    for (unsigned long int time = 500000; time--;);
                    CLEAR_DISP_SCREEN;
                    clcd_print("ENTER PASSWORD", LINE1(0));
                    attempt--;
                } else {
                    char str[4];
                    str[3] = '\0';
                    CLEAR_DISP_SCREEN;
                    clcd_print("YOU ARE BLOCKED", LINE1(0));
                    clcd_print("FOR     SECONDS", LINE2(0));
                    for (unsigned char time = 120; time--;) {
                        str[0] = time / 100 + 48;
                        str[2] = time % 10 + 48;
                        str[1] = ((time / 10) % 10) + 48;
                        clcd_print(str, LINE2(4));
                        for (unsigned int wait = 10; wait--;) {
                            for (unsigned int wait = 65000; wait--;);
                        }
                        attempt = 3;
                    }
                }
            }
        }
    }
}

/*once the user enters the correct password, they will allowed to enter the menu which
 displays the different logs */
void menu() {
    unsigned char key = ALL_RELEASED;
    unsigned int kcount;
    unsigned int hcount;
    unsigned int i = 0;
    unsigned int star = 0;
    char menu[][17] = {"View LOG        ", "DOWNLOAD LOG    ", "Clear Log       ", "Set TIME         ", "Change Password "};
    while (menuflag) {
        clcd_print(menu[i % 5], LINE1(1));
        clcd_print(menu[(i + 1) % 5], LINE2(1));
        if (star == 0) {
            clcd_putch('*', LINE1(0));
            clcd_putch(' ', LINE2(0));
        } else {
            clcd_putch('*', LINE2(0));
            clcd_putch(' ', LINE1(0));
        }
        key = read_switches(LEVEL_CHANGE);
        if (key == MK_SW12) {
            kcount++;
            if (kcount == 200) {
                menuflag = 0;
                continue;
            }
        } else if (key == MK_SW11) {
            hcount++;
            if (hcount == 200) {
                hcount = 0;
                switch ((i + star) % 5) {
                    case 0:
                        log_flag = 1;
                        viewlog();
                        break;
                    case 1:
                        downloadlog();
                        break;
                    case 2:
                        clearlog();
                        break;
                    case 3:
                        log_flag = 1;
                        settime();
                        break;
                    case 4:
                        log_flag = 1;
                        kflag = 0;
                        changepassword();
                        break;
                }
                CLEAR_DISP_SCREEN;
            }
        } else {
            if (kcount > 0 && kcount < 200) {
                if (i < 3 && star) {
                    i++;
                }
                star = 1;
            } else if (hcount > 0 && hcount < 200) {
                if (i > 0 && !star) {
                    i--;
                }
                star = 0;
            }
            kcount = 0;
            hcount = 0;
        }
    }
    CLEAR_DISP_SCREEN;
}

/*function to view all logs stored in external eeprom
 MK11: to scroll up
 MK12: to scroll down (short press)
       to enter the specific log (long press)*/
void viewlog() {
    CLEAR_DISP_SCREEN;
    clcd_print("Log:-", LINE1(0));
    unsigned char i, key = ALL_RELEASED, sno = 0, lap_check;
    if (overflowflag == 0) {
        lap_check = lap - 1;
    } else {
        lap_check = 9;
    }
    unsigned int kcount = 0, hcount = 0;
    if (overflowflag) {
        i = lap;
    } else {
        i = 0;
    }
    while (log_flag) {
        key = read_switches(LEVEL_CHANGE);
        if (key == MK_SW11) {
            kcount++;
        } else if (key == MK_SW12) {
            hcount++;
            if (hcount == 200) {
                log_flag = 0;
                continue;
            }
        } else {
            if (kcount > 0 && kcount < 200) {
                if (i < lap_check && sno < 9) {
                    i++;
                    sno++;
                }
            } else if (hcount > 0 && hcount < 200) {
                if (i > 0 && sno > 0) {
                    i--;
                    sno--;
                }
            }
            kcount = 0;
            hcount = 0;
        }
        printlog(i, sno);
    }
}
/*to collect logs from external eeprom and display them on clcd*/
void printlog(unsigned char i, unsigned char sno) {
    char arr[17] = "    :  :         ";
    arr[0] = sno + 48;
    arr[2] = read_ext_eeprom(i * 10 + 0);
    arr[3] = read_ext_eeprom(i * 10 + 1);
    arr[5] = read_ext_eeprom(i * 10 + 2);
    arr[6] = read_ext_eeprom(i * 10 + 3);
    arr[8] = read_ext_eeprom(i * 10 + 4);
    arr[9] = read_ext_eeprom(i * 10 + 5);
    arr[11] = read_ext_eeprom(i * 10 + 6);
    arr[12] = read_ext_eeprom(i * 10 + 7);
    arr[14] = read_ext_eeprom(i * 10 + 8);
    arr[15] = read_ext_eeprom(i * 10 + 9);
    clcd_print(arr, LINE2(0));
}

/*to download the logs that has been done(entered) by the user and display them on 
 * teraterm application using CAN communication protocol*/
void downloadlog(void) {
    save_event("DL");
    lap++;
    if (lap == 10) {
        overflowflag = 1;
        lap = 0;
    }
    puts("NO  TIME   EV SP\n\r");
    unsigned char i, limit;
    char arr[19] = "                   ";
    arr[16] = '\n';
    arr[17] = '\r';
    arr[18] = '\0';
    if (overflowflag) {
        i = lap;
        limit = 10;
    } else {
        i = 0;
        limit = lap;
    }
    for (char sno = 0; sno < limit; sno++) {
        arr[0] = sno + 48;
        arr[2] = read_ext_eeprom(i * 10 + 0);
        arr[3] = read_ext_eeprom(i * 10 + 1);
        arr[5] = read_ext_eeprom(i * 10 + 2);
        arr[6] = read_ext_eeprom(i * 10 + 3);
        arr[8] = read_ext_eeprom(i * 10 + 4);
        arr[9] = read_ext_eeprom(i * 10 + 5);
        arr[11] = read_ext_eeprom(i * 10 + 6);
        arr[12] = read_ext_eeprom(i * 10 + 7);
        arr[14] = read_ext_eeprom(i * 10 + 8);
        arr[15] = read_ext_eeprom(i * 10 + 9);
        puts(arr);
        if (++i == 10) {
            i = 0;
        }
    }
}

/*to clear the log*/
void clearlog() {
    CLEAR_DISP_SCREEN;
    lap = 0;
    overflowflag = 0;
    save_event("CL");
    lap++;
    if (lap == 10) {
        overflowflag = 1;
        lap = 0;
    }
    clcd_print("CLEARED",LINE1(0));
    for(unsigned long wait=500000;wait--;);
}

/*function to change password
 MKP11:read 0
 MKP12:read 1
 if the new password and new password re-entered matches, then password will be successfully changed*/
void changepassword(void) {
    char pass[5] = {};
    char repass[5] = {};
    CLEAR_DISP_SCREEN;
    unsigned int wait = 0, c1 = 0, c2 = 0, passflag = 1;
    unsigned char i = 0, key = ALL_RELEASED;
    clcd_print("NEW PASSWORD", LINE1(0));
    while (log_flag) {
        key = read_switches(LEVEL_CHANGE);
        if (wait++ < 12500) {
            clcd_putch('_', LINE2(i));
        } else if (wait++ < 25000) {
            clcd_putch(' ', LINE2(i));
        } else {
            wait = 0;
        }
        if (key == MK_SW11) {
            c1++;
        } else if (key == MK_SW12) {
            c2++;
            if (c2 == 200000) {
                log_flag = 0;
                continue;
            }
        } else {
            if (passflag) {
                if (c1 > 0 && c1 < 200000 && kflag) {
                    pass[i] = '0';
                    clcd_putch('*', LINE2(i));
                    i++;
                } else if (c2 > 0 && c2 < 200000 && kflag) {
                    pass[i] = '1';
                    clcd_putch('*', LINE2(i));
                    i++;
                }
                c1 = 0;
                c2 = 0;
                if (i == 4) {
                    passflag = 0;
                    i = 0;
                    CLEAR_DISP_SCREEN;
                    clcd_print("RE-ENTER PASSWORD", LINE1(0));
                }
            } else {
                if (c1 > 0 && c1 < 200000 && kflag) {
                    repass[i] = '0';
                    clcd_putch('*', LINE2(i));
                    i++;
                } else if (c2 > 0 && c2 < 200000 && kflag) {
                    repass[i] = '1';
                    clcd_putch('*', LINE2(i));
                    i++;
                }
                c1 = 0;
                c2 = 0;
                if (i == 4) {
                    if (strcmp(pass, repass) == 0) {
                        write_ext_eeprom(120, pass[0]);
                        write_ext_eeprom(121, pass[1]);
                        write_ext_eeprom(122, pass[2]);
                        write_ext_eeprom(123, pass[3]);
                        write_ext_eeprom(124, '*');
                        read_password();
                        save_event("CP");
                        lap++;
                        if (lap == 10) {
                            lap = 0;
                            overflowflag = 1;
                        }
                        CLEAR_DISP_SCREEN;
                        clcd_print("PASSWORD CHANGED", LINE1(0));
                        clcd_print("SUCCESSFULLY", LINE2(0));
                        for (unsigned long wait = 500000; wait--;);
                        log_flag = 0;
                        continue;
                    } else {
                        CLEAR_DISP_SCREEN;
                        clcd_print("PASSWORD NOT", LINE1(0));
                        clcd_print("MATCHED", LINE2(0));
                        for (unsigned long wait = 500000; wait--;);
                        log_flag = 0;
                        continue;
                    }
                }
            }
            kflag = 1;
        }
    }
}

/*function to set time or change the time
 MKP11:increment the selected field(short press)
       save the time and go back to menu(long press)
 MKP12:change the specific field selected(short press)
       go back to the menu(long press)*/
void settime() {
    char hour = (time[0] - 48)*10 + (time[1] - 48);
    char min = (time[3] - 48)*10 + (time[4] - 48);
    char sec = (time[6] - 48)*10 + (time[7] - 48);
    char field = 3;
    unsigned char key = ALL_RELEASED;
    char TIME[9];
    unsigned long c1 = 0, c2 = 0;
    for (char t = 0; t <= 8; t++) {
        TIME[t] = time[t];
    }
    CLEAR_DISP_SCREEN;
    clcd_print("HH:MM:SS", LINE1(0));
    clcd_print(TIME, LINE2(0));
    unsigned int wait = 0;
    while (log_flag) {
        key = read_switches(LEVEL_CHANGE);
        if (key == MK_SW11) {
            c1++;
            if (c1 == 2000) {
                savetime(hour, min, sec);
                log_flag = 0;
                break;
            }
        } else if (key == MK_SW12) {
            c2++;
            if (c2 == 2000) {
                log_flag = 0;
                continue;
            }
        } else {
            if (c1 > 0 && c1 < 2000) {
                if (field == 1) {
                    if (hour < 23) {
                        hour++;
                    } else {
                        hour = 0;
                    }
                } else if (field == 2) {
                    if (min < 59) {
                        min++;
                    } else {
                        min = 0;
                    }
                } else if (field == 3) {
                    if (sec < 59) {
                        sec++;
                    } else {
                        sec = 0;
                    }
                }
            } else if (c2 > 0 && c2 < 2000) {
                if (field > 1) {
                    field--;
                } else {
                    field = 3;
                }
            }
            c1 = 0;
            c2 = 0;
        }
        TIME[0] = hour / 10 + 48;
        TIME[1] = hour % 10 + 48;
        TIME[3] = min / 10 + 48;
        TIME[4] = min % 10 + 48;
        TIME[6] = sec / 10 + 48;
        TIME[7] = sec % 10 + 48;
        if (wait++ < 500) {
            if (field == 1) {
                TIME[0] = ' ';
                TIME[1] = ' ';
            }
            if (field == 2) {
                TIME[3] = ' ';
                TIME[4] = ' ';
            }
            if (field == 3) {
                TIME[6] = ' ';
                TIME[7] = ' ';
            }
        } else {
            if (wait == 1000) {
                wait = 0;
            }
        }
        clcd_print(TIME, LINE2(0));
    }
}

/*save the time to RTC registers*/
void savetime(char hour, char min, char sec) {
    char simp;
    /* Setting the CH bit of the RTC to Stop the Clock */
    simp = read_ds1307(SEC_ADDR);
    write_ds1307(SEC_ADDR, simp | 0x80);
    simp = read_ds1307(HOUR_ADDR);
    simp = (simp & 0xB0) | ((hour / 10) << 4) | (hour % 10);
    write_ds1307(HOUR_ADDR, simp);
    simp = read_ds1307(MIN_ADDR);
    simp = (simp & 0x80) | ((min / 10) << 4) | (min % 10);
    write_ds1307(MIN_ADDR, simp);
    simp = read_ds1307(SEC_ADDR);
    simp = (simp & 0x80) | ((sec / 10) << 4) | (sec % 10);
    write_ds1307(SEC_ADDR, simp);
    /* Clearing the CH bit of the RTC to Start the Clock */
    simp = read_ds1307(SEC_ADDR);
    write_ds1307(SEC_ADDR, simp & 0x7F);
}




